(function ($) {
    
$(window).load(function () {
    
});
    
$(document).ready(function () {
    /*
    Sample Slick JS Script
    https://kenwheeler.github.io/slick/

    $('#container').slick({
		centerMode: true,
		slidesToShow: 1,
		infinite: true,
		autoplay: true,
  		autoplaySpeed: 6000,
		prevArrow:"<button type='button' class='slick-prev pull-left'><i class='fa fa-angle-left' aria-hidden='true'></i></button>",
        nextArrow:"<button type='button' class='slick-next pull-right'><i class='fa fa-angle-right' aria-hidden='true'></i></button>",
		responsive: [
			{
				breakpoint: 1800,
				settings: {
					centerMode : false,
					slidesToShow: 2
				}
			},
			{
				breakpoint: 1350,
				settings: {
					centerMode : false,
					slidesToShow: 1
				}
			}
		]
	});
    */
});

})(jQuery);