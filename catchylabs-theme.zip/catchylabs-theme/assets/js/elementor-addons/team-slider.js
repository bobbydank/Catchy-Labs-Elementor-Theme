(function ($) {

$(document).ready(function() {

  /*if ($('.cl-icon-sliders').length) {
    $('.cl-icon-sliders .cl-icon-sliders-container').slick({
      dots: false,
      infinite: true,
      speed: 300,
      slidesToShow: 1,
      adaptiveHeight: true,
      prevArrow: $('.cl-icon-slider-controls .fa-arrow-left'),
      nextArrow: $('.cl-icon-slider-controls .fa-arrow-right')
    });
  }*/

});



})(jQuery);
